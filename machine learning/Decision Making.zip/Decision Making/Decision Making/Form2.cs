﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decision_Making
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a, b, c, d, f, g, h, j, k;
            double l, m, v;
            double x, y, z;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox5.Text);
            c = int.Parse(textBox4.Text);
            d = int.Parse(textBox3.Text);
            f = int.Parse(textBox8.Text);
            g = int.Parse(textBox10.Text);
            h = int.Parse(textBox2.Text);
            j = int.Parse(textBox7.Text);
            k = int.Parse(textBox9.Text);
            l = double.Parse(textBox15.Text);
            m = double.Parse(textBox13.Text);
            v = double.Parse(textBox14.Text);
            //---------------------------------------------
            x = l * a + m * b + v * c;
            textBox6.Text = x.ToString();
            //------------------------------------------------
            y = l * d + m * f + v * g;
            textBox11.Text = y.ToString();
            //-----------------------------------------------------
            z = l * h + m * j + v * k;
            textBox12.Text = z.ToString();
            //---------------------------------------------------------------
            if (x >= y & x >= z)
            {
                textBox16.Text = x.ToString();
            }
            else if (y >= x & y >= z)
            {
                textBox16.Text = y.ToString();
            }
            else
            {
                textBox16.Text = z.ToString();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();

        }
    }
}
