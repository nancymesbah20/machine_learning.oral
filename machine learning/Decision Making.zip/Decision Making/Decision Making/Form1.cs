﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Decision_Making
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a, b, c, d, f, g, h, i, j, k, l, m, o, n, w, q, r, s, p, I, H, M, D, B;
            int v, x, y, z;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);
            c = int.Parse(textBox3.Text);
            d = int.Parse(textBox4.Text);
            f = int.Parse(textBox5.Text);
            g = int.Parse(textBox6.Text);
            h = int.Parse(textBox7.Text);
            i = int.Parse(textBox8.Text);
            j = int.Parse(textBox9.Text);
            k = int.Parse(textBox10.Text);
            l = int.Parse(textBox11.Text);
            m = int.Parse(textBox1.Text);
            o = int.Parse(textBox20.Text);
            n = int.Parse(textBox21.Text);
            w = int.Parse(textBox22.Text);
            q = int.Parse(textBox24.Text);
            r = int.Parse(textBox25.Text);
            s = int.Parse(textBox26.Text);
            p = int.Parse(textBox28.Text);
            I = int.Parse(textBox29.Text);
            H = int.Parse(textBox30.Text);
            M = int.Parse(textBox32.Text);
            D = int.Parse(textBox33.Text);
            B = int.Parse(textBox34.Text);
            v = int.Parse(textBox19.Text);
            x = int.Parse(textBox18.Text);
            y = int.Parse(textBox12.Text);
            z = int.Parse(textBox16.Text);
            //----------------------------------------------------------------
            if(a>=d & a>=h & a>= k)
            {
               
            

            }
            else if (d>= a & d>= h & d>= k)
            {
               
            }
            else if (h>=a & h>=d & h >= k)
            {
                

            }
            else
            {
                


            }
            //-----------------------------------------------------------------
            if(b>= f & b>= i & b >= l)
            {
               
            }
            else if (f>= b & f>= i & f >= l)
            {
                

            }
            else if (i>=b & i>=f & i>= l)
            {
               
            }
            else
            {
                
            }
            //-----------------------------------------------------------------------------------
            if(c>=g & c>=j & c >= m)
            {
               

            }
            else if (g>=c & g>=j & g>= m)
            {
               

            }
            else if (j>=c & j>=g & j >= m)
            {
               

            }
            else
            {
               
            }
               //----------------------------------------------------------------------------------
            if(o>=n & o>= w)
            {
                textBox19.Text = o.ToString();
            } 
           else if(n>=o & n>= w)
            {
                textBox19.Text = n.ToString();
            }
            else
            {
                textBox19.Text = w.ToString();
            }
            //----------------------------------------------------------------------------------
            if(q>= r & q>= s)
            {
                textBox18.Text = q.ToString();
            }
            else if ( r>=q & r >= s)
            {
                textBox18.Text = r.ToString();
            }
            else
            {
                textBox18.Text = s.ToString();
            }
            //-------------------------------------------------------------------------
            if(p>=I & p>= H)
            {
                textBox12.Text = p.ToString();
            }
            else if (I >= p & I>= H)
            {
                textBox12.Text = I.ToString();
            }
            else
            {
                textBox12.Text = H.ToString();
            }
            //-----------------------------------------------------------------
            if(M>= D & M>= B)
            {
                textBox16.Text = M.ToString();
            }
            else if( D>= M & D>= B)
            {
                textBox16.Text = D.ToString();
            }
            else
            {
                textBox16.Text = B.ToString();

            }
            //------------------------------------------------------------------------------
            if(v<=x & v<=y & v<= z)
            {
                textBox13.Text = v.ToString();
            }
            else if (x<=v & x<= y & x<= z)
            {
                textBox13.Text = x.ToString();
            }
            else if (y<= v & y<= x & y<= z)
            {
                textBox13.Text = y.ToString();
            }
            else
            {
                textBox13.Text = z.ToString();
            }



            
                    


        }

        private void button3_Click(object sender, EventArgs e)
        {
            int a, b, c, d, f, g, h, i, j, k, l, m;
            int v, x, y, z;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);
            c = int.Parse(textBox3.Text);
            d = int.Parse(textBox4.Text);
            f = int.Parse(textBox5.Text);
            g = int.Parse(textBox6.Text);
            h = int.Parse(textBox7.Text);
            i = int.Parse(textBox8.Text);
            j = int.Parse(textBox9.Text);
            k = int.Parse(textBox10.Text);
            l = int.Parse(textBox11.Text);
            m = int.Parse(textBox1.Text);
            if (a <= b & a <= c)
            {
                v = a;
                textBox19.Text = v.ToString();

            }
            else if (b <= a & b <= c)
            {
                v = b;
                textBox19.Text = v.ToString();

            }

            else
            {
                v = c;
                textBox19.Text = v.ToString();
            }
            //------------------------------------------------
            if (d <= f & d <= g)
            {
                x = d;
                textBox18.Text = x.ToString();
            }
            else if (f <= d & f <= g)
            {
                x = f;
                textBox18.Text = x.ToString();
            }
            else
            {
                x = g;
                textBox18.Text = x.ToString();
            }
            //-----------------------------------------------------------
            if (h <= i & h <= j)
            {

                y = h;
                textBox12.Text = y.ToString();
            }
            else if (i <= h & i <= j)
            {
                y = h;
                textBox12.Text = y.ToString();

            }
            else
            {
                y = j;
                textBox12.Text = y.ToString();
            }
            //-----------------------------------------------------------
            if (k <= l & k <= m)
            {
                z = k;
                textBox16.Text = z.ToString();
            }
            else if (l <= k & l <= m)
            {
                z = l;
                textBox16.Text = z.ToString();
            }
            else
            {
                z = m;
                textBox16.Text = z.ToString();
            }
            //------------------------------------------------------------------
            if (v >= x & v >= y & v >= z)
            {
                textBox14.Text = v.ToString();
            }
            else if (x >= v & x >= y & x >= z)
            {
                textBox14.Text = x.ToString();
            }
            else if (y >= v & y >= x & y >= z)
            {
                textBox14.Text = y.ToString();
            }
            else
            {
                textBox14.Text = z.ToString();
            }


        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            int a, b, c, d, f, g, h, i, j, k, l, m;
            int v, x, y, z;
            a = int.Parse(textBox1.Text);
            b = int.Parse(textBox2.Text);
            c = int.Parse(textBox3.Text);
            d = int.Parse(textBox4.Text);
            f = int.Parse(textBox5.Text);
            g = int.Parse(textBox6.Text);
            h = int.Parse(textBox7.Text);
            i = int.Parse(textBox8.Text);
            j = int.Parse(textBox9.Text);
            k = int.Parse(textBox10.Text);
            l = int.Parse(textBox11.Text);
            m = int.Parse(textBox1.Text);
            if (a >= b && a >= c)
            {
                v = a;
                textBox19.Text = v.ToString();

            }
            else if (b >= a && b >= c)
            {
                v = b;
                textBox19.Text = v.ToString();

            }

            else
            {
                v = c;
                textBox19.Text = v.ToString();


            }
            //-----------------------------------------------------------
            if (d >= f && d >= g)
            {
                x = d;
                textBox18.Text = x.ToString();
            }
            else if (f >= d && f >= g)
            {
                x = f;
                textBox18.Text = x.ToString();
            }
            else
            {
                x = g;
                textBox18.Text = x.ToString();
            }
            //------------------------------------------------------------------------
            if (h >= i & h >= j)
            {

                y = h;
                textBox12.Text = y.ToString();
            }
            else if (i >= h & i >= j)
            {
                y = h;
                textBox12.Text = y.ToString();

            }
            else
            {
                y = j;
                textBox12.Text = y.ToString();
            }
            //-------------------------------------------------------------------------------
            if (k >= l && k >= m)
            {
                z = k;
                textBox16.Text = z.ToString();
            }
            else if (l >= k && l >= m)
            {
                z = l;
                textBox16.Text = z.ToString();
            }
            else
            {
                z = m;
                textBox16.Text = z.ToString();
            }
            //-----------------------------------------------------------------------------------
            if (v >= x && v >= y && v >= z)
            {
                textBox15.Text = v.ToString();
            }
            else if (x >= v && x >= y && x >= z)
            {
                textBox15.Text = x.ToString();
            }
            else if (y >= v && y >= x && y >= z)
            {
                textBox15.Text = y.ToString();
            }
            else
            {
                textBox15.Text = z.ToString();
            }



        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int o, n, w, q, r, s, p, I, H, M, D, B;
            double A, G, U;
            double L, R, W, Q;
            o = int.Parse(textBox20.Text);
            n = int.Parse(textBox21.Text);
            w = int.Parse(textBox22.Text);
            q = int.Parse(textBox24.Text);
            r = int.Parse(textBox25.Text);
            s = int.Parse(textBox26.Text);
            p = int.Parse(textBox28.Text);
            I = int.Parse(textBox29.Text);
            H = int.Parse(textBox30.Text);
            M = int.Parse(textBox32.Text);
            D = int.Parse(textBox33.Text);
            B = int.Parse(textBox34.Text);
            A = double.Parse(textBox40.Text);
            G = double.Parse(textBox37.Text);
            U = double.Parse(textBox38.Text);

            //------------------------------------------------------------------
            L = A * o + G * n + U * w;
            textBox23.Text = L.ToString();
            //---------------------------------------------------------------------
            R = A * q + G * r + U * s;
            textBox27.Text = R.ToString();
            //--------------------------------------------------------------------------
            W = A * p + G * I + U * H;
            textBox31.Text = W.ToString();
            //------------------------------------------------------------------------
            Q = A * M + G * D + U * B;
            textBox35.Text = Q.ToString();
            //-----------------------------------------------------------------------
            if(L>= R & L>= W & L >= Q)
            {
                textBox36.Text = L.ToString();
            }
            else if ( R>= L & R>= W & R >= Q)
            {
                textBox36.Text = R.ToString();
            }
            else if (W >= L & W>= R & W>= Q)
            {
                textBox36.Text = W.ToString();
            }
            else
            {
                textBox36.Text = Q.ToString();
            }
        }
    }
}
